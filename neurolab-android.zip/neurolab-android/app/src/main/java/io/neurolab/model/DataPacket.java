package io.neurolab.model;

public class DataPacket {
    // TODO: Implementation to be carried out in the future.
}
