package io.neurolab.main;

public class FakeLock {

    public FakeLock(){

    }

    public void lock(){

    }

    public void unlock(){
        
    }

}
